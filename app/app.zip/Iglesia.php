<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Iglesia extends Model
{
    protected $primaryKey = 'id';
    public function setNameAttribute($value)
    {
        $this->attributes['name'] = ucfirst(strtolower($value));
    }

    public function esMiembro(){
        return $this->belongsToMany(User::class);
    }

    public function asignarIglesia($id){
        $this->esMiembro()->sync($id, false);

    }
}
