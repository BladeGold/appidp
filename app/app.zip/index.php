<!DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Pagina Activada</title>
            <style>
                html, body {
                    width: 100%;
                    height: 100%;
                    margin: 0 auto;
                    text-align: center;
                    background: linear-gradient(135deg, #a4b3c5 0%, #3e4d5f 100%);
                }
                #content {
                    width: 100%;
                    position: absolute;
                    top: 45%;
                    transform: translateY(-50%);
                    font-family: verdana, helvetica, arial, sans-serif;
                    color: #ffffff;
                }
            </style>
        </head>
        <body><if>
                     <h1>PAGINA ACTIVADA</h1>
<p>Esta pagina web se encuentra en construcci&oacute;n.</p>
<p>Por favor, regresa luego.</p>
</div>
</body>
    </html>