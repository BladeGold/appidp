<?php

namespace App\Http\Controllers;

use App\Http\Requests\IglesiasCreateFormRequest;
use App\Iglesia;
use App\User;
use App\UserDate;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class IglesiaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct(){
        $this->middleware('auth');

    }
    public function validates(){
        if (empty(Iglesia::all()->toArray())==true){
            return false;
        }
        else{
            return true;
        }
    }
    public function index(Request $request)
    {    $validate= $this->validates();

        if ($validate==false){

            return view('iglesias.index', ['validate' => $validate]);
        }
        else{
            if ($request->ajax()){
                $iglesias=Iglesia::all();

                return DataTables::of($iglesias)

                    ->addColumn('action', 'iglesias.action')
                    ->rawColumns(['action'])
                    ->make(true);
            }

            return view('iglesias.index', ['validate' => $validate]);
        }


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(IglesiasCreateFormRequest $request)
    {
        if (empty($request)==false){
            $iglesia= new Iglesia();

            $iglesia->name= $request->get('name');

            $iglesia->save();

            return redirect('iglesias');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $iglesia = Iglesia::find($id);
        $user = Iglesia::find($id)->esMiembro;

        return view('iglesias.show',['users' => $user, 'iglesia' => $iglesia]);







    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
