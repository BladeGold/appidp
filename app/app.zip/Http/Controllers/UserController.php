<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserCreateFormRequest;
use App\Http\Requests\UserUpdateFormRequest;
use App\UserDate;
use App\User;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function validates(){

        if (empty(Auth::id())==false){
            $date = UserDate::find(Auth::id());
            if (empty($date)){
                return false;
            }
            elseif ($date['user_id']==Auth::id()){
                return true;
            }
        }

    }

    public function index()
    {

        $valida = $this->validates();
        switch ($valida){
            case true:
               return view('users.index');
                break;
            case false:
                return $this->create();
                break;
        }

    }

    public function create()
    {
        return view('users.regdate');
    }


    public function store(UserCreateFormRequest $request)
    {
        $valida = $this->validates();
        if ($valida==true){
            return view('users.index');
        }

        else {
            $date= new UserDate();
            $date->user_id=auth::id();
            $date->fecha_nacimiento=$request->get('fecha_nacimiento');
            $date->lugar_nacimiento=$request->get('lugar_nacimiento');
            $date->telefono=$request->get('telefono');
            $date->cedula=$request->get('cedula');
            $date->sexo=$request->get('sexo');
            $date->ciudad=$request->get('ciudad');
            $date->estado=$request->get('estado');
            $date->direccion=$request->get('direccion');
            $date->nacionalidad=$request->get('nacionalidad');
            $date->estado_civil=$request->get('estado_civil');

            $date->save();

            return $this->index();

        }

    }


    public function show($id)
    { $valida = $this->validates();
        if ($valida==true){
            return view('users.show_profile', ['user_date' => UserDate::Where('user_id', $id)->firstOrFail() , 'user'=>User::findOrFail($id)]);
        }
        else {
            return redirect('/users');
        }


    }


    public function edit($id)
    {
        $valida = $this->validates();
        if ($valida==false){

            return view('users.regdate');
        }

        else{
            return view('users.edit', ['user_date' => UserDate::Where('user_id', $id)->firstOrFail() , 'user'=>User::findOrFail($id)]);
        }
    }

    public function update(UserUpdateFormRequest $request, $id)
    {
        $date = UserDate::where('user_id', $id)->firstOrFail();
        $user = User::findOrFail($id);

        $user->name=$request->get('name');
        $user->last_name=$request->get('last_name');

        $date->user_id= Auth::id();
        $date->fecha_nacimiento=$request->get('fecha_nacimiento');
        $date->lugar_nacimiento=$request->get('lugar_nacimiento');
        $date->telefono=$request->get('telefono');
        $date->sexo=$request->get('sexo');
        $date->ciudad=$request->get('ciudad');
        $date->estado=$request->get('estado');
        $date->direccion=$request->get('direccion');
        $date->nacionalidad=$request->get('nacionalidad');
        $date->estado_civil=$request->get('estado_civil');
        if ($request->hasFile('imagen')){
            $file = $request->imagen;
            $collection = Str::of(Auth::user()->email)->explode('@');
            $filename = $collection[0].$collection[1].'.'.$file->extension();
            $ruta= public_path('/imgProfile/'.$filename) ;
            Image::make($file->getRealPath())
                ->resize(600,400, function ($constraint){
                        $constraint->aspectRatio();
                    })
                    ->save($ruta,72);
            $user->imagen=$filename;
        }
        $date->update();
       $user->update();
        return redirect('/users/'.Auth::id());
    }


    public function destroy($id)
    {
        //
    }





}
