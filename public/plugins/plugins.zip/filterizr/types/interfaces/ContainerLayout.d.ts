import { Position } from './Position';
export interface ContainerLayout {
    containerHeight: number;
    itemsPositions: Position[];
}
